package bb8.base;
import battlecode.common.*;

public abstract class Building extends Unit{
    public Building(RobotController rc){
        super(rc);
    }
}
