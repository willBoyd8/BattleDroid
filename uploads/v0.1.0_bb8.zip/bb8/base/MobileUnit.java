package bb8.base;
import battlecode.common.*;

public abstract class MobileUnit extends Unit {
    public MobileUnit(RobotController rc){
        super(rc);
    }

}
