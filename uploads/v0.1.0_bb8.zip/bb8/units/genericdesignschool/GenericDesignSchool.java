package bb8.units.genericdesignschool;

import bb8.base.Building;
import battlecode.common.*;

public class GenericDesignSchool extends Building {
    public GenericDesignSchool(RobotController rc){
        super(rc);
    }

    public void turn() throws GameActionException{

    }
}
