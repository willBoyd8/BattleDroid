package bb8.units.genericlandscaper;

import bb8.base.MobileUnit;
import battlecode.common.*;

public class GenericLandscaper extends MobileUnit {
    public GenericLandscaper(RobotController rc){
        super(rc);
    }

    public void turn() throws GameActionException{

    }
}
