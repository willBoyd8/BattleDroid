package bb8.units.genericvaporator;

import bb8.base.Building;
import battlecode.common.*;

public class GenericVaporator extends Building {
    public GenericVaporator(RobotController rc){
        super(rc);
    }

    public void turn() throws GameActionException{

    }
}
