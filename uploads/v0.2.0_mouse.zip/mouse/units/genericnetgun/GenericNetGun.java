package mouse.units.genericnetgun;

import battlecode.common.GameActionException;
import battlecode.common.RobotController;
import mouse.base.Building;

public class GenericNetGun extends Building {
    public GenericNetGun(RobotController rc){
        super(rc);
    }

    public void turn() throws GameActionException{

    }
}
