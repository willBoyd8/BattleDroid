package c3po.base;

public class KillMeNowException extends Exception {

}
