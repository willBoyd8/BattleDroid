package c3po.base;

import battlecode.common.RobotController;

public abstract class MobileUnit extends Unit {
    public MobileUnit(RobotController rc){
        super(rc);
    }

}
