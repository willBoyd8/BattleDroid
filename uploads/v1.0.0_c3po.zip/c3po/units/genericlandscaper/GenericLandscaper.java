package c3po.units.genericlandscaper;

import battlecode.common.GameActionException;
import battlecode.common.RobotController;
import c3po.base.MobileUnit;

public class GenericLandscaper extends MobileUnit {
    public GenericLandscaper(RobotController rc){
        super(rc);
    }

    public void turn() throws GameActionException{

    }
}
