package droideka.units.genericdesignschool;

import battlecode.common.GameActionException;
import battlecode.common.RobotController;
import droideka.base.Building;

public class GenericDesignSchool extends Building {
    public GenericDesignSchool(RobotController rc){
        super(rc);
    }

    public void turn() throws GameActionException{

    }
}
