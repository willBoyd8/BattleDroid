package droideka.units.genericvaporator;

import battlecode.common.GameActionException;
import battlecode.common.RobotController;
import droideka.base.Building;

public class GenericVaporator extends Building {
    public GenericVaporator(RobotController rc){
        super(rc);
    }

    public void turn() throws GameActionException{

    }
}
