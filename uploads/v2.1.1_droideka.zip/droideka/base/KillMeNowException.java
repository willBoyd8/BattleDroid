package droideka.base;

public class KillMeNowException extends Exception {

}
