package droideka.units.genericlandscaper;

import battlecode.common.GameActionException;
import battlecode.common.RobotController;
import droideka.base.MobileUnit;

public class GenericLandscaper extends MobileUnit {
    public GenericLandscaper(RobotController rc){
        super(rc);
    }

    public void turn() throws GameActionException{

    }
}
