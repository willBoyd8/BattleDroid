package commando.base;

public class KillMeNowException extends Exception {

}
