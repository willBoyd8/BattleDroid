package commando.base;

import battlecode.common.RobotController;

public abstract class Building extends Unit {
    public Building(RobotController rc){
        super(rc);
    }
}
