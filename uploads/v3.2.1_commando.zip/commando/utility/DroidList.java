package commando.utility;

import java.util.ArrayList;

public class DroidList<T> extends ArrayList<T> {

}
