package commando.units.genericnetgun;

import battlecode.common.GameActionException;
import battlecode.common.RobotController;
import commando.base.Building;

public class GenericNetGun extends Building {
    public GenericNetGun(RobotController rc){
        super(rc);
    }

    public void turn() throws GameActionException{

    }
}
