package commando.units.genericdesignschool;

import battlecode.common.GameActionException;
import battlecode.common.RobotController;
import commando.base.Building;

public class GenericDesignSchool extends Building {
    public GenericDesignSchool(RobotController rc){
        super(rc);
    }

    public void turn() throws GameActionException{

    }
}
