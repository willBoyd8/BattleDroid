package commando.units.genericlandscaper;

import battlecode.common.GameActionException;
import battlecode.common.RobotController;
import commando.base.MobileUnit;

public class GenericLandscaper extends MobileUnit {
    public GenericLandscaper(RobotController rc){
        super(rc);
    }

    public void turn() throws GameActionException{

    }
}
