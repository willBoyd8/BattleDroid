package commando.units.genericvaporator;

import battlecode.common.GameActionException;
import battlecode.common.RobotController;
import commando.base.Building;

public class GenericVaporator extends Building {
    public GenericVaporator(RobotController rc){
        super(rc);
    }

    public void turn() throws GameActionException{

    }
}
